<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress2' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '^yt$is6gc%)g8xvUwMT#1Ww?%UL9+*&HH28_Y2 n,oc$aC}FL-s}CB,Oyu`h]-l)' );
define( 'SECURE_AUTH_KEY',  'N]e|G)ru*m,vJe4H*E2aMhm9O,+3G]T[h:5$*EBl 8$s5HAta`i|ChPG*WFl=MQ/' );
define( 'LOGGED_IN_KEY',    'p/IMwfyj. jZZ~b$ja$}MOfa}GDVmg&q-L4{uhHe}i{v2noPX1p47<8fAK,#!a9@' );
define( 'NONCE_KEY',        'Fl7)YKu( Eydl}6;KJp7AE?/`U`D qSW89df!<1W)d:_]A&t_J_qcsta:Rs5abrc' );
define( 'AUTH_SALT',        '{S]L**~x~3uf{D=c]dxCrAgvbdvK<ia.GN1cY@]6^OUthtk`+vuq<m ~OC,> 3E1' );
define( 'SECURE_AUTH_SALT', 'by8>ifaN-2?Qzuy/k2@iK`x [mbmB+1~6XqR2JT`:3~I(,P&4NrB]<1;8vbwS(D:' );
define( 'LOGGED_IN_SALT',   '(@ Y#mlkU_/UTnwmg3~aG*tg*MWdu8GCzx=0VALMi><oZ~0UeC<w{1E6EBPsxuc#' );
define( 'NONCE_SALT',       'LN)gs i}y!AE1@5{=O%@{`){)@PjeP5ski<EPcUVZmxS1xv8aPL4~oxGiPji]:I=' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
